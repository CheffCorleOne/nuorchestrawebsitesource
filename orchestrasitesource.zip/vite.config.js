import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
base: '/',  
plugins: [react()],
  build: {
    assetsInlineLimit: 0, // Обрабатываем все ассеты (включая видео и большие GIF)
    rollupOptions: {
      output: {
        assetFileNames: 'assets/[name].[hash].[ext]'
      }
    }
  }
})