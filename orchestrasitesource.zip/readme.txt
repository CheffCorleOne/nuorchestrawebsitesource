install node js & npm


cmd & bash commands

- npm install #install dependencies
- npm run dev #for localhosting
- npm run build  #build when your code is ready